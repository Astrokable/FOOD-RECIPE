from django.urls import path
from . import views


app_name = 'djangofoodrecipeapp'

urlpatterns = [
    path('', views.index, name='index'),
    path('contact/', views.contact, name='contact'),
    path('about/', views.about, name='about'),
    path('snacks/', views.snack, name='snacks'),
    path('fullmeals/', views.fullmeal, name='fullmeals'),
    path('desserts/', views.dessert, name='desserts'),
    path('drinks/', views.drink, name='drinks'),
    path('recipe/<int:pk>', views.recipe, name='recipe'),
    path('recipef/<int:pk>', views.recipef, name='recipef'),
    path('reciped/<int:pk>', views.reciped, name='reciped'),
    path('recipedr/<int:pk>', views.recipedr, name='recipedr'),
    path('features/<int:pk>', views.features, name='features'),
]
