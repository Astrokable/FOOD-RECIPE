from django.contrib import admin
from .models import Contact, Snack, Fullmeal, Dessert, Drink, Featured

admin.site.register(Contact)
admin.site.register(Snack)
admin.site.register(Fullmeal)
admin.site.register(Dessert)
admin.site.register(Drink)
admin.site.register(Featured)
