from django.contrib import messages
from django.shortcuts import render, get_object_or_404
from .models import Contact, Snack, Fullmeal, Dessert, Drink, Featured


def index(request):
    features = Featured.objects.all()
    context = {
        'features': features,
    }
    return render(request, 'djangofoodrecipeapp/index.html', context)


def about(request):
    return render(request, 'djangofoodrecipeapp/about.html')


def contact(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        message = request.POST.get('message')
        find_us = Contact(name=name, email=email, message=message)
        find_us.save()
        messages.success(request, "Thank you for the feedback!!!")
    return render(request, 'djangofoodrecipeapp/contact.html')


def snack(request):
    snacks = Snack.objects.all()
    context = {
        'snacks': snacks,
    }
    return render(request, 'djangofoodrecipeapp/snacks.html', context)


def fullmeal(request):
    fullmeals = Fullmeal.objects.all()
    context = {
        'fullmeals': fullmeals,
    }
    return render(request, 'djangofoodrecipeapp/fullmeals.html', context)


def dessert(request):
    desserts = Dessert.objects.all()
    context = {
        'desserts': desserts,
    }
    return render(request, 'djangofoodrecipeapp/desserts.html', context)


def drink(request):
    drinks = Drink.objects.all()
    context = {
        'drinks': drinks,
    }
    return render(request, 'djangofoodrecipeapp/drinks.html', context)


# def featured(request):
#     features = Featured.objects.all()
#     context = {
#         'features': features,
#     }
#     return render(request, 'djangofoodrecipeapp/index.html', context)


def recipe(request, pk):
    recipes = get_object_or_404(Snack, pk=pk)
    context = {
        'recipes': recipes,
    }
    return render(request, 'djangofoodrecipeapp/recipe.html', context)


def recipef(request, pk):
    recipes = get_object_or_404(Fullmeal, pk=pk)
    context = {
        'recipes': recipes,
    }
    return render(request, 'djangofoodrecipeapp/recipe.html', context)


def reciped(request, pk):
    recipes = get_object_or_404(Dessert, pk=pk)
    context = {
        'recipes': recipes,
    }
    return render(request, 'djangofoodrecipeapp/recipe.html', context)


def recipedr(request, pk):
    recipes = get_object_or_404(Drink, pk=pk)
    context = {
        'recipes': recipes,
    }
    return render(request, 'djangofoodrecipeapp/recipe.html', context)


def features(request, pk):
    recipes = get_object_or_404(Featured, pk=pk)
    context = {
        'recipes': recipes
    }
    return render(request, 'djangofoodrecipeapp/recipe.html', context)
