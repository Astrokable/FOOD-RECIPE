from django.db import models


class Contact(models.Model):
    name = models.CharField(max_length=250)
    email = models.EmailField()
    message = models.TextField()

    def __str__(self):
        return self.name


class Snack(models.Model):
    name = models.CharField(max_length=250)
    time_to_cook = models.CharField(max_length=250)
    more_info = models.TextField()
    snack_images = models.ImageField(upload_to='images')

    def __str__(self):
        return self.name


class Fullmeal(models.Model):
    name = models.CharField(max_length=250)
    time_to_cook = models.CharField(max_length=250)
    more_info = models.TextField()
    fullmeal_images = models.ImageField(upload_to='images')

    def __str__(self):
        return self.name


class Dessert(models.Model):
    name = models.CharField(max_length=250)
    time_to_cook = models.CharField(max_length=250)
    more_info = models.TextField()
    dessert_images = models.ImageField(upload_to='images')

    def __str__(self):
        return self.name


class Drink(models.Model):
    name = models.CharField(max_length=250)
    time_to_cook = models.CharField(max_length=250)
    more_info = models.TextField()
    drink_images = models.ImageField(upload_to='images')

    def __str__(self):
        return self.name


class Featured(models.Model):
    name = models.CharField(max_length=250)
    basic = models.CharField(max_length=250)
    time_to_cook = models.CharField(max_length=250)
    more_info = models.TextField()
    featured_images = models.ImageField(upload_to='images')

    def __str__(self):
        return self.name
